#line 1 "/Users/mac/Downloads/BHADs/BHADs/BHADs.xm"
#import <UIKit/UIKit.h>
#import <CoreGraphics/CoreGraphics.h>
#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#import <GoogleMobileAds/GoogleMobileAds.h>



@interface WAChatListViewController : UIViewController
@end
@interface WAChatListViewController (BHADs) <GADBannerViewDelegate>
@end




#include <objc/message.h>
#if defined(__clang__)
#if __has_feature(objc_arc)
#define _LOGOS_SELF_TYPE_NORMAL __unsafe_unretained
#define _LOGOS_SELF_TYPE_INIT __attribute__((ns_consumed))
#define _LOGOS_SELF_CONST const
#define _LOGOS_RETURN_RETAINED __attribute__((ns_returns_retained))
#else
#define _LOGOS_SELF_TYPE_NORMAL
#define _LOGOS_SELF_TYPE_INIT
#define _LOGOS_SELF_CONST
#define _LOGOS_RETURN_RETAINED
#endif
#else
#define _LOGOS_SELF_TYPE_NORMAL
#define _LOGOS_SELF_TYPE_INIT
#define _LOGOS_SELF_CONST
#define _LOGOS_RETURN_RETAINED
#endif

__attribute__((unused)) static void _logos_register_hook$(Class _class, SEL _cmd, IMP _new, IMP *_old) {
unsigned int _count, _i;
Class _searchedClass = _class;
Method *_methods;
while (_searchedClass) {
_methods = class_copyMethodList(_searchedClass, &_count);
for (_i = 0; _i < _count; _i++) {
if (method_getName(_methods[_i]) == _cmd) {
if (_class == _searchedClass) {
*_old = method_getImplementation(_methods[_i]);
*_old = method_setImplementation(_methods[_i], _new);
} else {
class_addMethod(_class, _cmd, _new, method_getTypeEncoding(_methods[_i]));
}
free(_methods);
return;
}
}
free(_methods);
_searchedClass = class_getSuperclass(_searchedClass);
}
}
@class WAChatListViewController; @class WhatsAppAppDelegate; 
static Class _logos_superclass$_ungrouped$WhatsAppAppDelegate; static bool (*_logos_orig$_ungrouped$WhatsAppAppDelegate$application$didFinishLaunchingWithOptions$)(_LOGOS_SELF_TYPE_NORMAL WhatsAppAppDelegate* _LOGOS_SELF_CONST, SEL, id, id);static Class _logos_superclass$_ungrouped$WAChatListViewController; static void (*_logos_orig$_ungrouped$WAChatListViewController$viewDidLoad)(_LOGOS_SELF_TYPE_NORMAL WAChatListViewController* _LOGOS_SELF_CONST, SEL);

#line 16 "/Users/mac/Downloads/BHADs/BHADs/BHADs.xm"

static bool _logos_method$_ungrouped$WhatsAppAppDelegate$application$didFinishLaunchingWithOptions$(_LOGOS_SELF_TYPE_NORMAL WhatsAppAppDelegate* _LOGOS_SELF_CONST __unused self, SEL __unused _cmd, id arg1, id arg2) {
    (_logos_orig$_ungrouped$WhatsAppAppDelegate$application$didFinishLaunchingWithOptions$ ? _logos_orig$_ungrouped$WhatsAppAppDelegate$application$didFinishLaunchingWithOptions$ : (__typeof__(_logos_orig$_ungrouped$WhatsAppAppDelegate$application$didFinishLaunchingWithOptions$))class_getMethodImplementation(_logos_superclass$_ungrouped$WhatsAppAppDelegate, @selector(application:didFinishLaunchingWithOptions:)))(self, _cmd, arg1, arg2);
    
    [GADMobileAds configureWithApplicationID:@"ca-app-pub-2502501640180711~6511056315"];
    return YES;
}





static void _logos_method$_ungrouped$WAChatListViewController$viewDidLoad(_LOGOS_SELF_TYPE_NORMAL WAChatListViewController* _LOGOS_SELF_CONST __unused self, SEL __unused _cmd) {
    (_logos_orig$_ungrouped$WAChatListViewController$viewDidLoad ? _logos_orig$_ungrouped$WAChatListViewController$viewDidLoad : (__typeof__(_logos_orig$_ungrouped$WAChatListViewController$viewDidLoad))class_getMethodImplementation(_logos_superclass$_ungrouped$WAChatListViewController, @selector(viewDidLoad)))(self, _cmd);
    
    GADBannerView *bannerView2 = [[GADBannerView alloc]
                                  initWithAdSize:kGADAdSizeBanner];
    bannerView2.adUnitID = @"ca-app-pub-2502501640180711/2132827608";
    bannerView2.rootViewController = self;
    [bannerView2 loadRequest:[GADRequest request]];
    bannerView2.delegate = self;
    
    
    bannerView2.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:bannerView2];
    [self.view addConstraints:@[
                                [NSLayoutConstraint constraintWithItem:bannerView2
                                                             attribute:NSLayoutAttributeBottom
                                                             relatedBy:NSLayoutRelationEqual
                                                                toItem:self.bottomLayoutGuide
                                                             attribute:NSLayoutAttributeTop
                                                            multiplier:1
                                                              constant:0],
                                [NSLayoutConstraint constraintWithItem:bannerView2
                                                             attribute:NSLayoutAttributeCenterX
                                                             relatedBy:NSLayoutRelationEqual
                                                                toItem:self.view
                                                             attribute:NSLayoutAttributeCenterX
                                                            multiplier:1
                                                              constant:0]
                                ]];
}



 static void _logos_method$_ungrouped$WAChatListViewController$adViewDidReceiveAd$(_LOGOS_SELF_TYPE_NORMAL WAChatListViewController* _LOGOS_SELF_CONST __unused self, SEL __unused _cmd, GADBannerView * adView) {
    NSLog(@"adViewDidReceiveAd");
}



 static void _logos_method$_ungrouped$WAChatListViewController$adView$didFailToReceiveAdWithError$(_LOGOS_SELF_TYPE_NORMAL WAChatListViewController* _LOGOS_SELF_CONST __unused self, SEL __unused _cmd, GADBannerView * adView, GADRequestError * error) {
    NSLog(@"adView:didFailToReceiveAdWithError: %@", [error localizedDescription]);
}



 static void _logos_method$_ungrouped$WAChatListViewController$adViewWillPresentScreen$(_LOGOS_SELF_TYPE_NORMAL WAChatListViewController* _LOGOS_SELF_CONST __unused self, SEL __unused _cmd, GADBannerView * adView) {
    NSLog(@"adViewWillPresentScreen");
}


 static void _logos_method$_ungrouped$WAChatListViewController$adViewWillDismissScreen$(_LOGOS_SELF_TYPE_NORMAL WAChatListViewController* _LOGOS_SELF_CONST __unused self, SEL __unused _cmd, GADBannerView * adView) {
    NSLog(@"adViewWillDismissScreen");
}


 static void _logos_method$_ungrouped$WAChatListViewController$adViewDidDismissScreen$(_LOGOS_SELF_TYPE_NORMAL WAChatListViewController* _LOGOS_SELF_CONST __unused self, SEL __unused _cmd, GADBannerView * adView) {
    NSLog(@"adViewDidDismissScreen");
}



 static void _logos_method$_ungrouped$WAChatListViewController$adViewWillLeaveApplication$(_LOGOS_SELF_TYPE_NORMAL WAChatListViewController* _LOGOS_SELF_CONST __unused self, SEL __unused _cmd, GADBannerView * adView) {
    NSLog(@"adViewWillLeaveApplication");
}

static __attribute__((constructor)) void _logosLocalInit() {
{Class _logos_class$_ungrouped$WhatsAppAppDelegate = objc_getClass("WhatsAppAppDelegate"); _logos_superclass$_ungrouped$WhatsAppAppDelegate = class_getSuperclass(_logos_class$_ungrouped$WhatsAppAppDelegate); { _logos_register_hook$(_logos_class$_ungrouped$WhatsAppAppDelegate, @selector(application:didFinishLaunchingWithOptions:), (IMP)&_logos_method$_ungrouped$WhatsAppAppDelegate$application$didFinishLaunchingWithOptions$, (IMP *)&_logos_orig$_ungrouped$WhatsAppAppDelegate$application$didFinishLaunchingWithOptions$);}Class _logos_class$_ungrouped$WAChatListViewController = objc_getClass("WAChatListViewController"); _logos_superclass$_ungrouped$WAChatListViewController = class_getSuperclass(_logos_class$_ungrouped$WAChatListViewController); { _logos_register_hook$(_logos_class$_ungrouped$WAChatListViewController, @selector(viewDidLoad), (IMP)&_logos_method$_ungrouped$WAChatListViewController$viewDidLoad, (IMP *)&_logos_orig$_ungrouped$WAChatListViewController$viewDidLoad);}{ char _typeEncoding[1024]; unsigned int i = 0; _typeEncoding[i] = 'v'; i += 1; _typeEncoding[i] = '@'; i += 1; _typeEncoding[i] = ':'; i += 1; memcpy(_typeEncoding + i, @encode(GADBannerView *), strlen(@encode(GADBannerView *))); i += strlen(@encode(GADBannerView *)); _typeEncoding[i] = '\0'; class_addMethod(_logos_class$_ungrouped$WAChatListViewController, @selector(adViewDidReceiveAd:), (IMP)&_logos_method$_ungrouped$WAChatListViewController$adViewDidReceiveAd$, _typeEncoding); }{ char _typeEncoding[1024]; unsigned int i = 0; _typeEncoding[i] = 'v'; i += 1; _typeEncoding[i] = '@'; i += 1; _typeEncoding[i] = ':'; i += 1; memcpy(_typeEncoding + i, @encode(GADBannerView *), strlen(@encode(GADBannerView *))); i += strlen(@encode(GADBannerView *)); memcpy(_typeEncoding + i, @encode(GADRequestError *), strlen(@encode(GADRequestError *))); i += strlen(@encode(GADRequestError *)); _typeEncoding[i] = '\0'; class_addMethod(_logos_class$_ungrouped$WAChatListViewController, @selector(adView:didFailToReceiveAdWithError:), (IMP)&_logos_method$_ungrouped$WAChatListViewController$adView$didFailToReceiveAdWithError$, _typeEncoding); }{ char _typeEncoding[1024]; unsigned int i = 0; _typeEncoding[i] = 'v'; i += 1; _typeEncoding[i] = '@'; i += 1; _typeEncoding[i] = ':'; i += 1; memcpy(_typeEncoding + i, @encode(GADBannerView *), strlen(@encode(GADBannerView *))); i += strlen(@encode(GADBannerView *)); _typeEncoding[i] = '\0'; class_addMethod(_logos_class$_ungrouped$WAChatListViewController, @selector(adViewWillPresentScreen:), (IMP)&_logos_method$_ungrouped$WAChatListViewController$adViewWillPresentScreen$, _typeEncoding); }{ char _typeEncoding[1024]; unsigned int i = 0; _typeEncoding[i] = 'v'; i += 1; _typeEncoding[i] = '@'; i += 1; _typeEncoding[i] = ':'; i += 1; memcpy(_typeEncoding + i, @encode(GADBannerView *), strlen(@encode(GADBannerView *))); i += strlen(@encode(GADBannerView *)); _typeEncoding[i] = '\0'; class_addMethod(_logos_class$_ungrouped$WAChatListViewController, @selector(adViewWillDismissScreen:), (IMP)&_logos_method$_ungrouped$WAChatListViewController$adViewWillDismissScreen$, _typeEncoding); }{ char _typeEncoding[1024]; unsigned int i = 0; _typeEncoding[i] = 'v'; i += 1; _typeEncoding[i] = '@'; i += 1; _typeEncoding[i] = ':'; i += 1; memcpy(_typeEncoding + i, @encode(GADBannerView *), strlen(@encode(GADBannerView *))); i += strlen(@encode(GADBannerView *)); _typeEncoding[i] = '\0'; class_addMethod(_logos_class$_ungrouped$WAChatListViewController, @selector(adViewDidDismissScreen:), (IMP)&_logos_method$_ungrouped$WAChatListViewController$adViewDidDismissScreen$, _typeEncoding); }{ char _typeEncoding[1024]; unsigned int i = 0; _typeEncoding[i] = 'v'; i += 1; _typeEncoding[i] = '@'; i += 1; _typeEncoding[i] = ':'; i += 1; memcpy(_typeEncoding + i, @encode(GADBannerView *), strlen(@encode(GADBannerView *))); i += strlen(@encode(GADBannerView *)); _typeEncoding[i] = '\0'; class_addMethod(_logos_class$_ungrouped$WAChatListViewController, @selector(adViewWillLeaveApplication:), (IMP)&_logos_method$_ungrouped$WAChatListViewController$adViewWillLeaveApplication$, _typeEncoding); }} }
#line 93 "/Users/mac/Downloads/BHADs/BHADs/BHADs.xm"
